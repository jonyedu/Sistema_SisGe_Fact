<?php

return [
    //'router_prefix' => '/home',
    'router_prefix' => '/',
];
