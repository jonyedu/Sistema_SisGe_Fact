<style>
    body {
        font-size: 13px;
        font-family: Arial, Helvetica, sans-serif;
    }

    /* da el tamaño a toda la tabla y quita los espacios entre las celdas */
    .tableBodyAll {
        width: 100%;
        border-collapse: collapse;
    }

    /* configura el tamaño donde lista los productos */
    .configListProduct {
        font-size: 10px;
        text-align: right;
    }
</style>

<br>
<br><br>
<br>

<!-- Cabecera  -->
<table class="configTableCaberaAll configBorderItem topCabecera">
    <tr>
        <th>Nombres</th>
        <th>Ruc</th>
   
        <th>Direccion</th>
        <th>Razón Social</th>      
        <th>Correo</th>
        <th>Tipo de Pago</th>
        <th>Fecha de Compra</th>
        <th>Total de Factura</th>



    </tr>
    <?php if($factura != null): ?>
    <?php $__empty_1 = true; $__currentLoopData = $factura; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
        <td style="font-size: 10px;text-align: center;"><?php echo e($detalle->proveedor->FULLNAME); ?></td>
        <td class="configListProduct"><?php echo e($detalle->proveedor->ruc); ?></td>
        <td class="configListProduct"><?php echo e($detalle->proveedor->direccion); ?></td>
        <td class="configListProduct"><?php echo e($detalle->proveedor->razon_social); ?></td>
        <td class="configListProduct"><?php echo e($detalle->proveedor->correo); ?></td>
 
        <td class="configListProduct"><?php echo e($detalle->tipo_pago); ?></td>
        <td class="configListProduct"><?php echo e($detalle->fecha_compra); ?></td>
        <td class="configListProduct"><?php echo e($detalle->totalapagar); ?></td>


    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr>
        <td style="color: white;">0</td>
        <td style="color: white;">0</td>
        <td style="color: white;">0</td>
        <td style="color: white;">0</td>
        <td style="color: white;">0</td>
    </tr>
    <?php endif; ?>
    <?php endif; ?>

</table>
<?php /**PATH C:\xampp\htdocs\sisgebefact\resources\views/reports/Transaccion/ReporteCompra/partials/Body.blade.php ENDPATH**/ ?>