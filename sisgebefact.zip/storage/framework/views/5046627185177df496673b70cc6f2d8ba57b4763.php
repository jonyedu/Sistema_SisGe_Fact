<style>
    body {
        font-size: 13px;
        font-family: Arial, Helvetica, sans-serif;
    }

    /* da el tamaño a toda la tabla y quita los espacios entre las celdas */
    .tableBodyAll {
        width: 100%;
        border-collapse: collapse;
    }

    /* configura el tamaño donde lista los productos */
    .configListProduct {
        font-size: 10px;
        text-align: right;
    }
</style>



<!-- Cabecera  -->
<table class="tableBodyAll border">
    <tr>
        <th>Código Principal</th>
        <th>Cantidad</th>
        <th>Descripción</th>
        <th>Precio Unitario</th>
        <th>Precio Total</th>
    </tr>
    <?php if($factura_venta->DetalleVenta != null): ?>
    <?php $__empty_1 = true; $__currentLoopData = $factura_venta->DetalleVenta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
        <td style="font-size: 10px;text-align: center;"><?php echo e($detalle->producto->codigo); ?></td>
        <td class="configListProduct"><?php echo e((int)$detalle->cantidad); ?></td>
        <td style="font-size: 10px;text-align: left;"><?php echo e($detalle->producto->nombre); ?></td>
        <td class="configListProduct">$<?php echo e($detalle->valor); ?></td>
        <td class="configListProduct">$<?php echo e($detalle->total); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr>
        <td style="color: white;">0</td>
        <td style="color: white;">0</td>
        <td style="color: white;">0</td>
        <td style="color: white;">0</td>
        <td style="color: white;">0</td>
    </tr>
    <?php endif; ?>
    <?php endif; ?>

</table>
<?php /**PATH C:\xampp\htdocs\sisgebefact\resources\views/reports/Transaccion/FacturaVenta/partials/Body.blade.php ENDPATH**/ ?>