<style>
    body {
        font-size: 13px;
        font-family: Arial, Helvetica, sans-serif;
    }

    /* da el tamaño a toda la tabla y quita los espacios entre las celdas */
    .tableBodyAll {
        width: 100%;
        border-collapse: collapse;
    }

    /* configura el tamaño donde lista los productos */
    .configListProduct {
        font-size: 10px;
        text-align: right;
    }
</style>

<br>
<br><br>
<br>

<!-- Cabecera  -->
<table class="configTableCaberaAll configBorderItem topCabecera">
    <tr>
        <th>Nombres</th>
        <th>Cedula</th>
   
        <th>Direccion</th>
        <th>Telefono</th>
        <th>Correo</th>
    </tr>
    <?php if($proveedores != null): ?>
    <?php $__empty_1 = true; $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
        <td style="font-size: 10px;text-align: center;"><?php echo e($detalle->NOMBRESCLIENTEPRO); ?></td>
        <td class="configListProduct"><?php echo e($detalle->cedula); ?></td>
   
        <td class="configListProduct"><?php echo e($detalle->direccion); ?></td>
        <td class="configListProduct"><?php echo e($detalle->telefono); ?></td>
        <td class="configListProduct"><?php echo e($detalle->correo); ?></td>

    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr>
        <td style="color: white;">0</td>
        <td style="color: white;">0</td>
        <td style="color: white;">0</td>
        <td style="color: white;">0</td>
        <td style="color: white;">0</td>
    </tr>
    <?php endif; ?>
    <?php endif; ?>

</table>
<?php /**PATH C:\xampp\htdocs\sisgebefact\resources\views/reports/Transaccion/cliente/partials/Body.blade.php ENDPATH**/ ?>