<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title> <?php echo e($nombre_reporte); ?> </title>


</head>

<body>
    <!-- Cabecera  -->
    <?php echo $__env->make('reports.Transaccion.cliente.partials.Header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <br>
    <?php echo $__env->make('reports.Transaccion.cliente.partials.Body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <br>
    
    <?php echo $__env->make('reports.Transaccion.cliente.partials.Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     
</body>
<?php /**PATH C:\xampp\htdocs\sisgebefact\resources\views/reports/Transaccion/cliente/Cliente.blade.php ENDPATH**/ ?>